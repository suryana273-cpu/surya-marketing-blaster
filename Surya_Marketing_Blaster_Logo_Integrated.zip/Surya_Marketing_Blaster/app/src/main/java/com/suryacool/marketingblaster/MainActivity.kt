package com.suryacool.marketingblaster

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.rgb(244, 247, 251))
        }
        scroll.addView(layout)

        val title = TextView(this).apply {
            text = "SURYA MARKETING BLASTER"
            textSize = 21f
            setTextColor(Color.rgb(16, 33, 61))
            gravity = Gravity.CENTER_VERTICAL
        }
        layout.addView(title)

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.surya_cool_teknik_logo)
            adjustViewBounds = true
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            contentDescription = "Logo Surya Cool Teknik"
        }
        layout.addView(logo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(190)
        ).apply { topMargin = dp(12); bottomMargin = dp(8) })

        addText(layout, "Kelola kampanye promosi SURYA COOL TEKNIK melalui kanal resmi dan audiens yang telah memberikan persetujuan.", 14f)

        val campaign = EditText(this).apply { hint = "Nama kampanye (contoh: Promo Service AC)" }
        layout.addView(campaign, params())
        val message = EditText(this).apply {
            hint = "Tulis materi promosi"
            minLines = 4
            gravity = Gravity.TOP
        }
        layout.addView(message, params())

        addText(layout, "Pilih kanal publikasi", 16f)
        val channels = listOf("Facebook Page", "Instagram Business", "TikTok", "WhatsApp Business", "Telegram", "Website / Blog")
        val checks = mutableListOf<CheckBox>()
        channels.forEach { name ->
            val cb = CheckBox(this).apply { text = name; isChecked = false }
            checks.add(cb); layout.addView(cb)
        }

        val consent = CheckBox(this).apply {
            text = "Saya memastikan konten dan audiens sesuai izin serta aturan platform."
        }
        layout.addView(consent)
        val approval = CheckBox(this).apply {
            text = "Saya akan meninjau dan menyetujui konten sebelum dipublikasikan."
        }
        layout.addView(approval)

        val schedule = EditText(this).apply { hint = "Jadwal publikasi (contoh: 2026-12-01 09:00)" }
        layout.addView(schedule, params())

        val button = Button(this).apply { text = "Simpan sebagai draf" }
        layout.addView(button, params())
        val result = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY) }
        layout.addView(result)

        button.setOnClickListener {
            val selected = checks.filter { it.isChecked }.joinToString { it.text }
            if (campaign.text.isBlank() || message.text.isBlank()) {
                result.text = "Isi nama kampanye dan materi promosi terlebih dahulu."
            } else if (!consent.isChecked || !approval.isChecked) {
                result.text = "Centang konfirmasi izin audiens dan persetujuan konten sebelum menyimpan draf."
            } else if (selected.isBlank()) {
                result.text = "Pilih minimal satu kanal publikasi."
            } else {
                result.text = "Draf siap ditinjau.\nKampanye: ${campaign.text}\nKanal: $selected\nJadwal: ${schedule.text.ifBlank { "Belum ditentukan" }}\n\nBelum ada iklan yang dikirim. Hubungkan API resmi platform pada tahap integrasi."
            }
        }

        addText(layout, "Catatan: versi awal ini hanya menyimpan alur draf pada layar. Publikasi otomatis memerlukan integrasi API resmi, akun bisnis yang berwenang, serta persetujuan platform.", 12f)
        setContentView(scroll)
    }

    private fun addText(parent: LinearLayout, value: String, size: Float) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.rgb(75, 91, 111))
            setPadding(0, dp(12), 0, dp(10))
        })
    }

    private fun params() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }
}
