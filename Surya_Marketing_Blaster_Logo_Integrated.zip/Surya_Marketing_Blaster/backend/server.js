const express = require('express');
const app = express();
app.use(express.json({ limit: '1mb' }));

// Starter API: stores campaign drafts only. Add authenticated, official
// platform integrations here after reviewing each platform's developer rules.
app.get('/health', (_req, res) => res.json({ ok: true, service: 'Surya Marketing Blaster' }));

app.post('/campaigns/draft', (req, res) => {
  const { name, content, channels, audienceConsent, approved } = req.body || {};
  if (!name || !content || !Array.isArray(channels) || channels.length === 0) {
    return res.status(400).json({ error: 'name, content, and channels are required' });
  }
  if (audienceConsent !== true || approved !== true) {
    return res.status(403).json({ error: 'Consent and human approval are required' });
  }
  // No sending is performed in this starter project.
  return res.status(201).json({
    status: 'draft_saved_for_review',
    name, channels,
    note: 'Connect only approved official platform APIs for publishing.'
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API listening on ${port}`));
