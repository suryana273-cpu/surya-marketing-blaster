# Surya Marketing Blaster — Starter Project

Proyek awal Android Studio (Kotlin) + backend Node.js untuk mengelola draf kampanye promosi.

## Fitur prototipe
- Form nama kampanye dan materi promosi.
- Pilihan kanal: Facebook Page, Instagram Business, TikTok, WhatsApp Business, Telegram, Website/Blog.
- Kolom jadwal publikasi.
- Konfirmasi izin audiens dan persetujuan manusia.
- Backend contoh hanya menerima dan menyimpan alur draf (belum terhubung database dan belum mengirim iklan).

## Membuka proyek
1. Ekstrak ZIP di komputer.
2. Buka Android Studio.
3. Pilih **Open** lalu pilih folder `Surya_Marketing_Blaster`.
4. Tunggu Gradle Sync selesai.
5. Jalankan pada emulator atau HP Android dengan USB debugging.
6. Untuk membuat APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Menjalankan backend contoh
Perlu Node.js terpasang:
```bash
cd backend
npm install
npm start
```
Tes status: `GET http://localhost:3000/health`

## Integrasi publikasi selanjutnya
Setiap kanal memerlukan akun/izin yang sesuai dan integrasi API resmi masing-masing platform. Contohnya Meta Graph API untuk aset bisnis yang memenuhi syarat, TikTok developer/business APIs sesuai ketersediaan, WhatsApp Business Platform, Telegram Bot API, serta API/CMS website.
Jangan menyimpan kata sandi akun sosial media di aplikasi. Gunakan OAuth/token resmi, simpan rahasia di backend, dan batasi akses.

## Penggunaan yang diperbolehkan
- Promosi ke halaman/akun yang kamu kelola.
- Konten yang disetujui dan relevan.
- Penerima pesan yang telah opt-in/menyetujui komunikasi.
- Jadwal dan frekuensi sesuai batas API serta kebijakan platform.
- Sediakan cara berhenti berlangganan untuk pesan promosi.

## Tidak termasuk
- Spam massal, DM tanpa persetujuan, komentar otomatis berulang, pembuatan akun massal, bypass CAPTCHA/rate limit, atau pengiriman tanpa izin.
- Pengiriman iklan nyata belum diaktifkan dalam starter ini.

\n## Identitas merek
Logo resmi yang diberikan pengguna sudah disertakan di:
`app/src/main/res/drawable-nodpi/surya_cool_teknik_logo.png`
Logo ditampilkan pada halaman utama aplikasi.
